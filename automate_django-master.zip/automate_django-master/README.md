# automate_django

This can be used as an alternative to firebase for realtime appliance status updates to connected devices
